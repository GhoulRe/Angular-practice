import { Component, OnInit } from '@angular/core';
import { ShareDataService } from '../share-data.service';


@Component({
  selector: 'app-a-component',
  templateUrl: './a-component.component.html',
  styleUrls: ['./a-component.component.css']
})
export class AComponentComponent implements OnInit{
  value="";

  constructor(private shareData:ShareDataService){}

  ngOnInit(){
    this.shareData.newMessage.subscribe(message =>this.value = message)
  }

 getData(){
  console.log(this.value);
  this.shareData.updateMessage(this.value);
 }
}
