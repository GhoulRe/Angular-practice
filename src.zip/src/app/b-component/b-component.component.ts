import { Component,OnInit } from '@angular/core';
import { ShareDataService } from '../share-data.service';


@Component({
  selector: 'app-b-component',
  templateUrl: './b-component.component.html',
  styleUrls: ['./b-component.component.css']
})
export class BComponentComponent implements OnInit {
   value='';

   constructor(private shareData:ShareDataService){}
 
  ngOnInit(){
    this.shareData.newMessage.subscribe(message =>this.value = message)
  }
}
