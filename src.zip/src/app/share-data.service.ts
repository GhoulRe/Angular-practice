import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShareDataService {

  private shareMessage = new BehaviorSubject('vikrant');
  newMessage = this.shareMessage.asObservable();
  constructor() { }
  updateMessage(message:string){
    this.shareMessage.next(message);
  }
}
